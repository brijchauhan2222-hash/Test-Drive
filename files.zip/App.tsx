import { useState } from 'react';
import { ArrowUpRight, Crown, Award, X } from 'lucide-react';

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  const navLinks = ['Treatments', 'Wellness', 'About', 'Contact'];

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black">
      {/* Background Video */}
      <video
        autoPlay
        muted
        loop
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
      >
        <source
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260606_154941_df1a96e1-a06f-450c-bd02-d863414cc1a0.mp4"
          type="video/mp4"
        />
      </video>

      {/* Dark Overlay */}
      <div className="absolute inset-0 bg-black/40 z-10" />

      {/* Navbar */}
      <nav className="absolute top-0 left-0 right-0 z-30 px-6 sm:px-10 lg:px-16 py-5 lg:py-7 flex items-center justify-between">
        {/* Brand Name */}
        <div className="font-podium text-2xl sm:text-3xl tracking-wider uppercase font-bold text-white">
          Dr. Nitin Chauhan
        </div>

        {/* Center Nav Links (hidden below md) */}
        <div className="hidden md:flex items-center gap-8 absolute left-1/2 -translate-x-1/2">
          {navLinks.map((link) => (
            <a
              key={link}
              href="#"
              className="font-inter text-sm text-white/80 tracking-widest uppercase hover:text-white transition-colors"
            >
              {link}
            </a>
          ))}
        </div>

        {/* Right Section */}
        <div className="ml-auto">
          {/* Desktop CTA Button (hidden below md) */}
          <button className="hidden md:flex items-center gap-2 border border-white/30 hover:border-white/60 px-6 py-3 text-xs tracking-widest uppercase text-white hover:bg-white/10 transition-all group">
            Book Appointment
            <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </button>

          {/* Mobile Hamburger (visible below md) */}
          {!menuOpen && (
            <button
              onClick={() => setMenuOpen(true)}
              className="md:hidden flex flex-col gap-1.5"
            >
              <div className="w-6 h-0.5 bg-white" />
              <div className="w-6 h-0.5 bg-white" />
              <div className="w-4 h-0.5 bg-white" />
            </button>
          )}
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div
        className={`fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex flex-col transition-all duration-500 ${
          menuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
        }`}
      >
        {/* Mobile Menu Header */}
        <div className="px-6 sm:px-10 py-5 flex items-center justify-between">
          <div className="font-podium text-2xl sm:text-3xl tracking-wider uppercase font-bold text-white">
            Dr. Nitin
          </div>
          <button
            onClick={() => setMenuOpen(false)}
            className="text-white hover:text-white/70 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Menu Links */}
        <div className="flex-1 flex flex-col items-center justify-center gap-8">
          {navLinks.map((link, i) => (
            <a
              key={link}
              href="#"
              onClick={() => setMenuOpen(false)}
              className="font-podium text-4xl sm:text-5xl uppercase text-white"
              style={{
                transition: 'opacity 0.5s ease-out, transform 0.5s ease-out',
                opacity: menuOpen ? 1 : 0,
                transform: menuOpen ? 'translateY(0)' : 'translateY(20px)',
                transitionDelay: menuOpen ? `${i * 80 + 100}ms` : '0ms',
              }}
            >
              {link}
            </a>
          ))}

          {/* Mobile CTA Button */}
          <button
            onClick={() => setMenuOpen(false)}
            className="flex items-center gap-2 border border-white/30 hover:border-white/60 px-6 py-3 text-xs tracking-widest uppercase text-white hover:bg-white/10 transition-all mt-4"
            style={{
              transition: 'opacity 0.5s ease-out, transform 0.5s ease-out',
              opacity: menuOpen ? 1 : 0,
              transform: menuOpen ? 'translateY(0)' : 'translateY(20px)',
              transitionDelay: menuOpen ? `${navLinks.length * 80 + 100}ms` : '0ms',
            }}
          >
            Book Appointment
            <ArrowUpRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Hero Content */}
      <div className="absolute inset-0 z-20 flex items-center justify-start px-6 sm:px-10 lg:px-16 pt-20">
        <div className="max-w-2xl">
          {/* Tagline */}
          <div className="flex items-center gap-3 mb-6 lg:mb-8 animate-fade-up opacity-0">
            <Crown className="w-4 h-4 text-white/70" />
            <span className="text-white/70 text-xs sm:text-sm font-inter tracking-[0.3em] uppercase">
              Ancient Wisdom, Modern Healing
            </span>
          </div>

          {/* Main Heading */}
          <h1
            className="font-podium uppercase leading-[0.92] tracking-tight text-white animate-fade-up-delay-1 opacity-0"
            style={{ fontSize: 'clamp(2.8rem, 8vw, 7rem)' }}
          >
            <div>Restore.</div>
            <div>Rebalance.</div>
            <div>Revitalize.</div>
          </h1>

          {/* Subtext */}
          <p className="text-white/70 text-sm sm:text-base font-inter leading-relaxed max-w-md mt-6 lg:mt-8 animate-fade-up-delay-2 opacity-0">
            Holistic Ayurvedic treatments tailored to your unique constitution{' '}
            <span className="text-white font-semibold">for lasting wellness.</span>
          </p>

          {/* CTA Row */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6 mt-8 lg:mt-10 animate-fade-up-delay-3 opacity-0">
            <button className="group bg-white hover:bg-neutral-200 px-5 sm:px-7 py-3 sm:py-4 text-[11px] sm:text-xs tracking-widest uppercase text-black font-semibold flex items-center gap-2 transition-all">
              Book Consultation
              <ArrowUpRight className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>

            {/* Award Badge (hidden on mobile) */}
            <div className="hidden sm:flex items-center gap-3">
              <Award className="w-8 h-8 text-white/50" />
              <div>
                <div className="text-white/60 text-xs tracking-wider uppercase font-inter">
                  Certified
                </div>
                <div className="text-white/60 text-xs tracking-wider uppercase font-inter">
                  Ayurvedic Physician
                </div>
              </div>
            </div>
          </div>

          {/* Stats Row */}
          <div className="flex flex-wrap gap-6 sm:gap-12 lg:gap-16 mt-8 sm:mt-10 lg:mt-14 animate-fade-up-delay-4 opacity-0">
            {[
              { value: '15+', label: 'Years Experience' },
              { value: '5K+', label: 'Patients Healed' },
              { value: '100%', label: 'Personalized Care' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="font-inter text-white text-2xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
                  {stat.value}
                </div>
                <div className="text-white/50 text-[9px] sm:text-xs tracking-widest uppercase font-inter mt-1">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
