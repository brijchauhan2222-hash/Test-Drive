# 🚀 Deploy in 5 Minutes

## Step 1: Install & Run Locally
```bash
npm install
npm run dev
```
Opens at http://localhost:5173

## Step 2: Push to GitHub
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

## Step 3: Deploy to Vercel
**Option A - CLI (Recommended)**
```bash
npm i -g vercel
vercel
```
Follow the prompts → Your site is live!

**Option B - GitHub Integration**
1. Go to vercel.com
2. Click "Import Project"
3. Select your GitHub repo
4. Vercel auto-deploys on every push

---

## Your Site Features

✅ Fullscreen hero with background video
✅ Responsive mobile menu
✅ Smooth animations
✅ Fully customizable content
✅ Automated tests on GitHub
✅ One-click deployment

---

## What Happens When You Push Code

1. **You push to GitHub** → `git push`
2. **GitHub Actions runs tests** → Automatically checks your code
3. **Tests pass?** → Green ✅ badge
4. **Vercel deploys** → Your changes go live instantly
5. **Tests fail?** → Red ❌ badge (fixes required before deploy)

---

## Customize Everything

See `README.md` for detailed customization guide:
- Change doctor name
- Edit nav links
- Modify hero text
- Update stats
- Change colors
- Replace background video

---

## Live Example

After deploying to Vercel, you'll get a URL like:
```
https://dr-nitin-chauhan-ayurveda.vercel.app
```

Share this with clients!

---

**Questions?** Check README.md for full documentation.
