# Dr. Nitin Chauhan - Ayurvedic Wellness Landing Page

A modern, fully responsive hero landing page for Dr. Nitin Chauhan's Ayurvedic practice in Madanpur Khadar. Built with React, Tailwind CSS, and Vite.

## Features

✨ **Fully Responsive** - Mobile-first design that works perfectly on all devices
🎬 **Fullscreen Video Hero** - Immersive background video with overlay
⚡ **Modern Animations** - Smooth fade-up animations with staggered delays
📱 **Mobile Menu** - Responsive hamburger menu for small screens
🎨 **Custom Typography** - Premium font stack (Podium + Inter)
♿ **Accessible** - Semantic HTML and ARIA labels
🚀 **Performance Optimized** - Fast builds with Vite

## Tech Stack

- **React 18** - UI framework
- **Vite** - Lightning-fast build tool
- **Tailwind CSS** - Utility-first CSS framework
- **TypeScript** - Type-safe development
- **Lucide React** - Beautiful SVG icons
- **GitHub Actions** - Automated testing on every push

## Quick Start

### 1. **Clone & Install**
```bash
git clone <your-repo-url>
cd dr-nitin-chauhan
npm install
```

### 2. **Run Locally**
```bash
npm run dev
```
Opens at `http://localhost:5173`

### 3. **Build for Production**
```bash
npm run build
```
Generates optimized files in `/dist` folder

### 4. **Deploy to Vercel**
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```
Choose project settings and you're live!

---

## File Structure

```
dr-nitin-chauhan/
├── src/
│   ├── App.tsx              # Main landing page component
│   ├── main.tsx             # React entry point
│   └── index.css            # Global styles & animations
├── index.html               # HTML template
├── package.json             # Dependencies & scripts
├── tailwind.config.js       # Tailwind configuration
├── tsconfig.json            # TypeScript config
├── vite.config.ts           # Vite configuration
├── .github/workflows/
│   └── test.yml             # GitHub Actions CI/CD
└── README.md                # This file
```

---

## Customization Guide

### **Change the Brand Name**
In `App.tsx`, line 31:
```jsx
<div className="font-podium text-2xl sm:text-3xl tracking-wider uppercase font-bold text-white">
  Dr. Nitin Chauhan  {/* ← Change here */}
</div>
```

### **Edit Navigation Links**
In `App.tsx`, line 13:
```jsx
const navLinks = ['Treatments', 'Wellness', 'About', 'Contact'];  // ← Update these
```

### **Change Hero Heading (Restore. Rebalance. Revitalize.)**
In `App.tsx`, around line 77:
```jsx
<h1>
  <div>Restore.</div>      {/* ← Change line 1 */}
  <div>Rebalance.</div>    {/* ← Change line 2 */}
  <div>Revitalize.</div>   {/* ← Change line 3 */}
</h1>
```

### **Modify Hero Subtext**
In `App.tsx`, line 87:
```jsx
<p>
  Holistic Ayurvedic treatments tailored to your unique constitution{' '}
  <span className="text-white font-semibold">for lasting wellness.</span>
  {/* ← Edit this text */}
</p>
```

### **Update CTA Buttons**
Search for "Book Consultation" and "Book Appointment" in `App.tsx` and replace with your calls-to-action.

### **Modify Stats**
In `App.tsx`, around line 105:
```jsx
{[
  { value: '15+', label: 'Years Experience' },      {/* ← Update */}
  { value: '5K+', label: 'Patients Healed' },        {/* ← Update */}
  { value: '100%', label: 'Personalized Care' },     {/* ← Update */}
].map((stat) => (...))}
```

### **Change Background Video**
Replace the CloudFront URL in `App.tsx`, line 33:
```jsx
<source
  src="https://your-video-url.mp4"  {/* ← Change here */}
  type="video/mp4"
/>
```

### **Adjust Colors**
Edit `tailwind.config.js` to customize color scheme. Current colors:
- Background: Black with dark overlay
- Text: White with opacity variations
- Accents: White/neutral

---

## Automated Testing

This project includes **GitHub Actions CI/CD** that automatically:
1. Runs tests on every push
2. Blocks bad code from merging
3. Deploys to Vercel on success

**See tests run:**
1. Push code to GitHub
2. Go to repo → **Actions** tab
3. Watch the workflow execute

---

## Deployment (Vercel)

### **Option 1: Vercel CLI (Easiest)**
```bash
npm i -g vercel
vercel
```
Follow prompts → Done!

### **Option 2: Git Push Deploy**
1. Connect GitHub repo to Vercel (vercel.com)
2. Every push auto-deploys
3. Preview URLs for PRs

### **Option 3: Manual Build**
```bash
npm run build
# Upload `/dist` folder to any static hosting
```

---

## Mobile Responsiveness

All sizes adapt automatically via Tailwind breakpoints:
- **Mobile**: < 640px
- **Tablet**: 640px - 1024px (`sm:`, `lg:` prefixes)
- **Desktop**: > 1024px

Test on real devices:
```bash
# Get your IP address (Mac/Linux)
ifconfig | grep inet

# Visit from mobile: http://YOUR_IP:5173
```

---

## Performance Tips

✅ **Video Optimization**
- Keep video under 5MB for fast loads
- Use WebM format for modern browsers
- Mobile-friendly bitrate (2-3 Mbps)

✅ **Image Optimization**
- Replace large images with Vercel Image Optimization
- Use `next/image` if migrating to Next.js

✅ **Code Splitting**
- Vite auto-splits code
- No manual optimization needed

---

## Troubleshooting

**Q: Video won't play on mobile**
A: Add `playsInline` (already done) and ensure video codec is H.264

**Q: Fonts look wrong**
A: Check Google Fonts and online-webfonts load correctly in DevTools

**Q: Animations too fast/slow**
A: Edit animation values in `tailwind.config.js`:
```js
'animation': {
  'fade-up': 'fade-up 0.8s ease-out forwards',  // ← Change 0.8s
}
```

**Q: Menu overlay isn't working**
A: Ensure `useState` is imported in `App.tsx`

---

## Need Help?

- **Vite Docs**: https://vitejs.dev
- **Tailwind CSS**: https://tailwindcss.com/docs
- **React**: https://react.dev
- **Lucide Icons**: https://lucide.dev

---

## License

This project is yours to customize and deploy. No restrictions.

---

**Ready to launch?** 🚀

```bash
npm install
npm run dev
```

Then deploy to Vercel when ready!
